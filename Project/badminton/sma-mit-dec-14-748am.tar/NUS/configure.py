#!/usr/bin/env  python2.3

#network_side = "MIT"
network_side = "NUS"


#GAME Engine Info
    
host_game_engine = 'soccf-smasrv01.ddns.comp.nus.edu.sg'
#'localhost' #'18.187.6.63'

#'172.18.181.109' # soccf-smasrv01.ddns.comp.nus.edu.sg

port_game_engine = 16069    # fixed

addrGE = (host_game_engine,port_game_engine)

localhost = 'soccf-smasrv01.ddns.comp.nus.edu.sg' #'localhost' #'18.187.6.63'

#'172.18.181.109' # soccf-smasrv01.ddns.comp.nus.edu.sg

scale = 6.32   # court scale, constant

#differentiate all the ports below in case two sites' code run on the same machine

port_gui0_location0=9999
#port_gui0_location0=16070
port_gui0_location1=9998
#port_gui0_location1=16071

port_gui1_location0=9997
#port_gui1_location0=16072
port_gui1_location1=9996
#port_gui1_location1=16073

port_masterlocator0=9995
#port_masterlocator0=16001
port_masterlocator1=9994
#port_masterlocator1=16002

port_querylocator0=9993
#port_querylocator0=15001
port_querylocator1=9992
#port_querylocator1=15002

# speech server configuration here

#IF set to 'test', QL will always return HIT. Else, will actually evaluate the ball
QueryLocatorMode='real'
