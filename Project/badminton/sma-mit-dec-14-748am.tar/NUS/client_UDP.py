#!/usr/bin/python

from socket import *
#host=raw_input("Please enter server IP:")


host = '18.187.6.63'
buf = 1024
port=15001

sock = socket(AF_INET,SOCK_DGRAM)
addr=((host, port))


print 'Starting client ---to ip', host, 'port', port
for i in range(5):
	sock.sendto('DATA!', addr)
print "Client complete -- exiting"


