
killall queryLocator.py
killall gui.py 
killall masterLocator.py