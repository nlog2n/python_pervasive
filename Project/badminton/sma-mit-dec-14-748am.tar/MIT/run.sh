
python queryLocator.py &
python gui.py &
python masterLocator.py &